create view ordervalues(orderid, custid, empid, shipperid, orderdate, val) as
SELECT o.orderid,
       o.custid,
       o.empid,
       o.shipperid,
       o.orderdate,
       sum(od.qty::numeric * od.unitprice * (1::numeric - od.discount))::numeric(12, 2) AS val
FROM tropico.orders o
         JOIN tropico.orderdetails od ON o.orderid = od.orderid
GROUP BY o.orderid, o.custid, o.empid, o.shipperid, o.orderdate;

alter table ordervalues
    owner to "postgresMaster";

